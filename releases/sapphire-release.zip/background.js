chrome.webRequest.onBeforeRequest.addListener((req => {
     if (/\/app-950\.chunk\.js|trackjs|\/logger/.test(req.url)) return {
        cancel: true
    }
}), {
    urls: ["*://*.i-ready.com/*"]
}, ["blocking"]);